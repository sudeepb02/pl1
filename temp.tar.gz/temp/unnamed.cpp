#include<iostream>
#include<unistd.h>

using namespace std;

int main(int argc,char* argv[])
{
	ssize_t bread,bwritten;
	char msg[] = "Hello world!\n";
	char rmsg[100];

	int fd[3];
	int a = pipe(fd);

	int ch = fork();

	if(ch==0)
	{
		cout<<"This is child process";
		close(fd[0]);
		bwritten = write(fd[1],msg,sizeof(msg));
	}
	else
	{
		cout<<"This is parent process";
		close(fd[1]);
		bread = read(fd[0],rmsg,sizeof(msg));
		cout<<rmsg;
	}
	return 0;
}


