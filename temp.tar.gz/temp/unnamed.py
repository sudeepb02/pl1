import os,sys

r,w = os.pipe()
msg = "Hello world!"

ch = os.fork()
if(ch==0):
	os.close(r)
	w1 = os.fdopen(w,'w')
	w1.write(msg)
else:
	os.close(w)
	r1 = os.fdopen(r)
	s1 = r1.read()
	print s1

