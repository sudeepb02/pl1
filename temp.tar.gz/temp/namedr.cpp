#include<iostream>
#include<string.h>
#include<sys/types.h>
#include<fcntl.h>
#include<unistd.h>

using namespace std;

int main(int argc,char* argv[])
{
	char buff[100];
	ssize_t bread;

	int fd = open("fifo",O_RDONLY);

	bread = read(fd,buff,100);
	cout<<buff;
	return 0;
}

