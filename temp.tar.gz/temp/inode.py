import os,sys,stat,time

n = int(raw_input("Enter number of files : "))
fname = []
for i in range(n):
	fname.append(raw_input("Enter file name : "))

for i in range(n):
	info = os.stat(fname[i])
	print("===========================")
	print(fname[i])
	if(stat.S_ISBLK(info.st_mode)):
		print("Block file ")
	elif(stat.S_ISDIR(info.st_mode)):
		print("Directory")
	elif(stat.S_ISFIFO(info.st_mode)):
		print("FIFO")
	elif(stat.S_ISLNK(info.st_mode)):
		print("Link")
	elif(stat.S_ISCHR(info.st_mode)):
		print("Character file")
	elif(stat.S_ISREG(info.st_mode)):
		print("Regular file")

	print("----")

	print("Inode number : ",info.st_ino)
	print("UID : ",info.st_uid)
	print("Number of links : ",info.st_nlink)
	print("Size : ",info.st_size)
	print("Last accessed : ",time.ctime(info.st_atime))
	print("Last changed : ",time.ctime(info.st_ctime))
	print("Last modified : ",time.ctime(info.st_mtime))


