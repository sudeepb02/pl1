#include<iostream>
#include<sys/types.h>
#include<string.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>

using namespace std;

int main(int argc,char* argv[])
{
	ssize_t bwritten;
	char msg[] = "Hello world!";

	mkfifo("fifo",0777);
	int fd = open("fifo",O_WRONLY);
	bwritten = write(fd,msg,strlen(msg));
	
	return 0;
}

