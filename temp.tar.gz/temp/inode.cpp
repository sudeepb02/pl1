#include<iostream>
#include<sys/stat.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>

using namespace std;

int main(int argc,char* argv[])
{
	struct stat info;
	if(argc<=1)
	{
		cout<<"Please pass command line arguments";
		exit(1);
	}

	for(int i=1;i<argc;i++)
	{
		int retvalue = lstat(argv[i],&info);

		cout<<"============================="<<endl;
		cout<<argv[i]<<": \t\t";
		
		if(S_ISDIR(info.st_mode))
		{
			cout<<"Directory\n";
		}
		else if(S_ISREG(info.st_mode))
		{
			cout<<"Regular file \n";
		}
		else if(S_ISBLK(info.st_mode))
		{
			cout<<"Block file \n";
		}
		else if(S_ISCHR(info.st_mode))
		{
			cout<<"Character file \n";
		}
		else if(S_ISFIFO(info.st_mode))
		{
			cout<<"FIFO\n";
		}
		else if(S_ISLNK(info.st_mode))
		{
			cout<<"link\n";
		}

		cout<<"----------"<<endl;

		cout<<"Inode no. : "<<info.st_ino<<endl;
		cout<<"UID : "<<info.st_uid<<endl;
		cout<<"Number of links : "<<info.st_nlink<<endl;
		cout<<"Size : "<<info.st_size<<endl;
		cout<<"Time last accessed : "<<ctime(&info.st_atime)<<endl;
	}
	return 0;
}


